import {
  DeleteObjectCommand,
  GetObjectCommand,
  ListObjectsV2Command,
  PutObjectCommand,
} from "@aws-sdk/client-s3";
import { s3 } from "./s3";

const Bucket = process.env.S3_BUCKET_NAME;
const Prefix = "openings/";

function assertEnv() {
  if (!Bucket) throw new Error("Missing S3_BUCKET_NAME");
  if (!process.env.REGION && !process.env.APP_AWS_REGION) {
    throw new Error("Missing REGION");
  }
}

function keyForId(id) {
  return `${Prefix}${id}.json`;
}

async function streamToString(stream) {
  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }
  return Buffer.concat(chunks).toString("utf-8");
}

function normalizeOpening(opening) {
  if (!opening || typeof opening !== "object") return opening;

  return {
    ...opening,
    side: opening.side || "w",
  };
}

export async function listOpenings() {
  assertEnv();

  const listed = await s3.send(
    new ListObjectsV2Command({
      Bucket,
      Prefix,
    })
  );

  const keys = (listed.Contents || [])
    .map((item) => item.Key)
    .filter((key) => key && key.endsWith(".json"));

  const openings = await Promise.all(
    keys.map(async (Key) => {
      const res = await s3.send(
        new GetObjectCommand({
          Bucket,
          Key,
        })
      );

      const text = await streamToString(res.Body);
      return normalizeOpening(JSON.parse(text));
    })
  );

  return openings.sort((a, b) => a.name.localeCompare(b.name));
}

export async function getOpening(id) {
  assertEnv();

  const res = await s3.send(
    new GetObjectCommand({
      Bucket,
      Key: keyForId(id),
    })
  );

  const text = await streamToString(res.Body);
  return normalizeOpening(JSON.parse(text));
}

export async function saveOpening(opening) {
  assertEnv();

  if (!opening?.id) {
    throw new Error("Opening id is required");
  }

  const normalized = normalizeOpening(opening);

  await s3.send(
    new PutObjectCommand({
      Bucket,
      Key: keyForId(normalized.id),
      Body: JSON.stringify(normalized, null, 2),
      ContentType: "application/json",
    })
  );

  return { ok: true, key: keyForId(normalized.id) };
}

export async function deleteOpening(id) {
  assertEnv();

  await s3.send(
    new DeleteObjectCommand({
      Bucket,
      Key: keyForId(id),
    })
  );

  return { ok: true };
}
