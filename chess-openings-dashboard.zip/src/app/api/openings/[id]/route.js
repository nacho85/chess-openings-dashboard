import { NextResponse } from "next/server";
import { getOpening, saveOpening, deleteOpening } from "@/server/openings-store";

function isAdmin(req) {
  if (process.env.NODE_ENV !== "production") return true;

  const cookie = req.headers.get("cookie") || "";
  const adminSecret = process.env.ADMIN_SECRET;
  return !!adminSecret && cookie.includes(`opening_admin=${adminSecret}`);
}

export async function GET(_req, { params }) {
  try {
    const opening = await getOpening(params.id);
    return NextResponse.json({ ok: true, opening });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error.message },
      { status: 500 }
    );
  }
}

export async function PUT(req, { params }) {
  try {
    if (!isAdmin(req)) {
      return NextResponse.json(
        { ok: false, error: "Unauthorized" },
        { status: 401 }
      );
    }

    const body = await req.json();
    const opening = { ...body.opening, id: params.id };

    const result = await saveOpening(opening);

    return NextResponse.json({ ok: true, file: result.key });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error.message },
      { status: 500 }
    );
  }
}

export async function DELETE(req, { params }) {
  try {
    if (!isAdmin(req)) {
      return NextResponse.json(
        { ok: false, error: "Unauthorized" },
        { status: 401 }
      );
    }

    await deleteOpening(params.id);

    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error.message },
      { status: 500 }
    );
  }
}
